const hamburger = document.getElementById('hamburger');
const navbar = document.getElementById('navbar');

hamburger.addEventListener('click', () => {
    navbar.classList.toggle('open');
});

// เลือกทุกๆ img ภายใน .img-container
const images1 = document.querySelectorAll('#party-pic');
const images2 = document.querySelectorAll('#wedd-pic');

const div_a4_1 = document.querySelector('#title1');
const div_a4_2 = document.querySelector('#title2');
// เมื่อ hover ที่รูปภาพ
images1.forEach(image => {
    image.addEventListener('mouseenter', () => {
        document.body.style.backgroundColor = 'black'; // เปลี่ยนสีของ body
        if (div_a4_1) {
            div_a4_2.style.display = 'none';
            div_a4_1.style.borderColor = 'white'; // เปลี่ยนสี border
            div_a4_1.style.color = 'white'
            div_a4_1.style.display = 'flex';
        }
    });
});
images2.forEach(image => {
    image.addEventListener('mouseenter', () => {
        document.body.style.backgroundColor = 'white'; // คืนสีเดิม
        if (div_a4_2) {
            div_a4_1.style.display = 'none';  // ซ่อน title2
            div_a4_2.style.borderColor = 'black'; // เปลี่ยนสี border
            div_a4_2.style.color = 'black'
            div_a4_2.style.display = 'flex';
        }
    });
});

